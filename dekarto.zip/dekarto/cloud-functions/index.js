const functions = require('firebase-functions');
const admin = require('firebase-admin');

const stripe = require("stripe")("sk_test_pgV8EG9WiPs1nDymE9WQFd5x");

const TRIP_STATUS_WAITING = 'waiting';
const TRIP_STATUS_GOING = 'going';
const TRIP_STATUS_FINISHED = 'finished';
const PAYMENT_METHOD_CARD = 'card';

admin.initializeApp();

exports.sendPush = functions.database.ref('notifications/{notification}').onWrite((change, context) => {

    const original = change.after.val();

    if (original.type === 'riders') {

        admin.database().ref('passengers').once('value', (snap) => {
            snap.forEach(u => {
                let user = u.val()
                return user.isPushEnabled ? sendMessage(user.pushToken, original.title, original.description) : false;
            })
        })

    }
    else if (original.type === 'drivers') {

        admin.database().ref('drivers').once('value', (snap) => {
            snap.forEach(u => {
                let user = u.val()
                return user.isPushEnabled ? sendMessage(user.pushToken, original.title, original.description) : false;
            })
        })

    }
    else if (original.type === 'both') {

        admin.database().ref('passengers').once('value', (snap) => {
            snap.forEach(u => {
                let user = u.val()
                return user.isPushEnabled ? sendMessage(user.pushToken, original.title, original.description) : false;

            })
        })

        admin.database().ref('drivers').once('value', (snap) => {
            snap.forEach(u => {
                let user = u.val()
                return user.isPushEnabled ? sendMessage(user.pushToken, original.title, original.description) : false
            })
        })

    }


})

function sendMessage(token, title, message) {

    if (token === undefined || token === '' || token === null) {
        return true;
    }
    else {
        return admin.messaging().sendToDevice([token], {
            notification: {
                title: title,
                body: message,
                sound: 'default'
            }
        }).then(() => {
            return true;
        }).catch(() => {
            return false;
        });
    }
}

exports.deleteRider = functions.database.ref('/passengers/{id}').onDelete((change, context) => {
    const id = context.params.id;

    admin.auth().deleteUser(id).then(() => {
        console.log("Deleted: " + id);
        return false
    }).catch(err => {
        console.log(err);
        return false;
    });
});

exports.deleteDriver = functions.database.ref('/drivers/{id}').onDelete((change, context) => {
    const id = context.params.id;
    admin.auth().deleteUser(id).then(() => {
        console.log("Deleted: " + id);
        return false
    }).catch(err => {
        console.log(err);
        return false;
    });
});

exports.makeReport = functions.database.ref('/trips/{tripId}').onWrite((change, context) => {

    if (!change.before.val()) {
        return false;
    }

    const original = change.after.val();
    const oldStatus = change.before.val().status;
    const tripId = context.params.tripId;

    if ((oldStatus === TRIP_STATUS_WAITING) && (original.status === TRIP_STATUS_GOING)) {

        var fee = parseFloat(original.fee).toFixed(2);

        console.log("Trips status: Waiting -> Going")

        // process payment
        if (original.paymentMethod === PAYMENT_METHOD_CARD) {

            // format currency
            if (original.currency === '$') {
                console.log("Card is ready to charge");
                return admin.database().ref('passengers/' + original.passengerId + '/card').once('value').then((snapshot) => {
                    console.log(snapshot.val());
                    return stripe.charges.create({
                        amount: parseInt(fee * 100),
                        currency: 'usd',
                        source: snapshot.val().token,
                        description: "Charge for tripId: " + context.params.tripId
                    }, { idempotencyKey: context.params.tripId }, (err, charge) => {
                        // console.log(err);
                        // console.log(charge);
                        if (err === null) {
                            console.log("STRIPE CHARGED:" + fee);
                            admin.database().ref('trips/' + tripId).update({
                                paymentStatus: 'success',
                                paymentId: charge.id
                            });

                            admin.database().ref('drivers/' + original.driverId).once('value').then((snapshot) => {
                                // console.log(snapshot.val());
                                if (snapshot !== null && snapshot !== undefined) {
                                    var updatedBalance = (parseFloat(snapshot.val().balance) + parseFloat(original.commission)).toFixed(2);
                                    console.log(updatedBalance);
                                    return admin.database().ref('drivers/' + original.driverId).update({
                                        balance: updatedBalance
                                    });
                                }
                                else
                                    return false;
                            }).catch(e => {
                                console.log("Fetching Driver Error");
                                return false;
                            });

                        } else {
                            console.log("STRIPE CHARGED FAILED:" + fee);
                            return admin.database().ref('trips/' + tripId).update({ paymentStatus: 'failed' });
                        }
                    });
                }).catch(e => {
                    console.log("Error while retriving token from customer");
                    return false;
                });
            } else {
                console.log('Currency ' + original.currency + ' is not supported');
                return false;
            }
        }
    }

    // Apply Rating After Trip completion

    if ((original.status === TRIP_STATUS_FINISHED) && (oldStatus === TRIP_STATUS_GOING)) {

        return admin.database().ref('/trips').orderByChild('driverId').equalTo(original.driverId).once('value', (snap) => {
            var stars = 0;
            var count = 0;
            if (snap !== null) {
                snap.forEach((trip) => {
                    if (trip.val().rating !== null && trip.val().rating !== undefined) {
                        stars += trip.val().rating;
                        count++
                    }
                });
                var rating = (stars / count).toFixed(1);
                console.log("Rating:" + rating);

                if (!isNaN(rating))
                    admin.database().ref('/drivers/' + original.driverId).update({ rating: rating });
            }

        });


        return true;
    }

    else {
        return false;
    }

});